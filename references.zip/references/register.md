# Register

Register describes how formal, spoken, professional, direct, warm, or restrained the copy feels.

## Rewrite rule

A rewrite preserves the source register unless the user explicitly requests a different one. Do not silently formalize contractions, slang, punctuation, or conversational phrasing.

## Generation rule

When generating from scratch, use the exemplar's declared baseline and the channel's expectations. Apply brand constraints after establishing the exemplar stance.

## Final check

Ask: Would the intended audience naturally speak or read this way in this channel? If not, adjust register without changing the exemplar's underlying stance.

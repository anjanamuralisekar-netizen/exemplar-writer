# Language Level

Default: **B2 (CEFR)**.

## Levels

| Level | Guidance |
|---|---|
| A2 | Very simple vocabulary, short sentences, concrete ideas, minimal subordinate clauses. |
| B1 | Familiar vocabulary, clear explanations, moderate sentence variety, limited idiom. |
| B2 | Clear professional English, useful abstraction, controlled complexity, natural sentence variety. **Default.** |
| C1 | Nuanced vocabulary, longer structures where useful, subtle distinctions and denser reasoning. |
| C2 | Highly precise, flexible, sophisticated language; use only when audience and purpose justify it. |

## Rules

- Treat the requested reader level as a ceiling, not a target for complexity.
- Simplify structure as well as vocabulary when moving down a level.
- Do not make copy childish merely because it is simple.
- Preserve necessary domain terminology; explain it when the audience may not know it.
- Avoid idioms, cultural references, and figurative language that create unnecessary comprehension load at lower levels.
- For rewrites, preserve meaning and factual content while changing linguistic complexity.

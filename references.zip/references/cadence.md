# Cadence

Cadence controls rhythm independently from exemplar and register.

## Refine for these machine-like tells

1. Repeated negation/reveal structures.
2. The same three-part list pattern in every paragraph.
3. Anaphora stacked too often.
4. Repeated sentence fragments used as dramatic beats.
5. Every section ending with an aphoristic mic-drop.
6. Repeated callbacks or identical closing moves.

## Redistribution rule

Use an exemplar-native rhetorical device as a seasoning, not a template applied to every paragraph. Vary sentence length, paragraph shape, openings, and endings.

## Read-aloud pass

Read the copy mentally or aloud. Mark places where the rhythm becomes predictable, breathless, sing-song, or artificially punchy. Rewrite those passages before delivery.

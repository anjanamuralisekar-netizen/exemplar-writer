# Custom Channel

Use this reference when the destination is not one of the stock channels.

## Input

```markdown
# Channel
Name: <channel>
Purpose: <job>
Audience: <reader>
Structure: <required shape>
Constraints: <length, formatting, platform rules>
Extends: <optional stock channel>
```

## Routing

- If `Extends:` is absent, the custom channel replaces stock channel constraints.
- If `Extends:` is present, inherit the stock channel and add the custom constraints.
- Preserve the exact exemplar-to-character mapping.
- Apply CEFR, cadence, and register after channel constraints are understood.
- Do not invent platform conventions that were not supplied when they materially affect the output.

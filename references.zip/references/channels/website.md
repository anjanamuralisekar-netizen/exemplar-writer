# Website Channel

## Purpose
Make value immediately understandable and move the reader toward a meaningful next action.

## Structure
Typical flow: headline → subheadline → proof/benefit → details → objections → CTA. Use only the sections the page needs.

## Constraints
- Lead with the reader's problem or desired outcome.
- Prefer concrete benefits over feature dumping.
- Keep headings scannable.
- Do not invent proof, statistics, testimonials, or guarantees.
- Preserve the selected exemplar while keeping conversion clarity.

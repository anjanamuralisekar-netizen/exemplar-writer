# Microcopy Channel

## Purpose
Deliver a small piece of copy where every word has a job.

## Structure
One idea, usually one sentence or phrase.

## Constraints
- Cut filler aggressively.
- Prefer concrete verbs.
- Avoid cleverness that competes with comprehension.
- Preserve the exemplar's stance in miniature.
- If space is constrained, protect meaning before personality.

# UI Channel

## Purpose
Help a user understand an interface state and take the correct next action.

## Structure
Message → consequence/context → action. Use labels and helper text only when they add clarity.

## Constraints
- Be concise and explicit.
- Put the important information first.
- Use familiar verbs for actions.
- Avoid jokes or rhetorical flourish when they could slow comprehension.
- Error messages should explain what happened and what the user can do next when known.

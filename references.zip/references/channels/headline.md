# Headline Channel

## Purpose
Earn attention while communicating a specific idea or benefit.

## Structure
One dominant promise, tension, insight, or outcome.

## Constraints
- Prefer specificity over generic cleverness.
- Keep the central meaning clear without the supporting paragraph.
- Avoid unsupported superlatives.
- Use the exemplar's stance, but do not turn every headline into a slogan.

# Email Channel

## Purpose
Move a reader from context to understanding to action without unnecessary ceremony.

## Structure
Subject → greeting → reason for writing → key information → requested action/next step → sign-off.

## Constraints
- Match the sender's relationship with the recipient.
- Keep the ask explicit.
- Avoid unnecessary throat-clearing.
- Preserve the requested register.
- Never invent facts, deadlines, attachments, or commitments.

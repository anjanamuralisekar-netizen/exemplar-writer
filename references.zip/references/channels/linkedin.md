# LinkedIn Channel

## Purpose
Communicate a useful point of view in a professional but human format.

## Structure
Hook → context/problem → insight → implication → optional practical takeaway or question.

## Constraints
- One clear idea per post.
- Avoid corporate filler and generic motivational language.
- Use short paragraphs for scanability.
- Keep expertise visible without sounding performative.
- Do not manufacture personal experiences, results, or credentials.

# Composite Exemplars

A composite uses multiple exemplars with **distinct jobs**. Do not average their voices into an indistinct middle.

## Fixed resolution

- Sita
- Savitri
- Janu
- Yashoda
- Durga
- Tara
- Mohini
- Ahalya
- Anjana
- Megha
- Rathi
- Rani

## Recommended format

```markdown
# Persona

## Cast
- Sita: explain the problem and establish truth.
- Durga: drive the action and CTA.

## Priority
Sita leads the body; Durga leads the close.
```

## Rules

1. Resolve every exemplar to its fixed character.
2. Assign each component a rhetorical role.
3. Decide which component leads when roles conflict.
4. Draft with role separation rather than blending every sentence.
5. Refine for cadence so the hand-offs feel intentional.
6. Apply channel, reading-level, and register constraints across the final piece.

If a `# Persona` body is missing a required `## Cast` section, report the conformance error rather than silently treating it as a stock exemplar.
